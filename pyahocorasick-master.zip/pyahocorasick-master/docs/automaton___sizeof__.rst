Return the approximate size in bytes occupied by the Automaton instance in
memory excluding the size of associated objects when the Automaton is created
with Automaton() or Automaton(ahocorasick.STORE_ANY).
