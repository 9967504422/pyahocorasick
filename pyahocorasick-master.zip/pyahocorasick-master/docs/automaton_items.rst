items([prefix, [wildcard, [how]]])
----------------------------------------------------------------------

Return an iterator on tuples of (key, value).
Keys are matched optionally to the prefix using the same logic
and arguments as in the keys() method.
